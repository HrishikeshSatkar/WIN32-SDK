#pragma once
extern "C" int SumOfTwoIntegers(int, int);
